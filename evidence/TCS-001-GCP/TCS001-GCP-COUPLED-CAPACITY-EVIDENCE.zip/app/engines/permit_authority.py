from __future__ import annotations

import hashlib
import hmac
import json
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from app.engines.authority_context_epoch import current_authority_context_epoch

_PERMIT_KEY = os.environ.get(
    "FLOWSIGNAL_EXECUTION_PERMIT_KEY",
    "flowsignal-reference-harness-ec0014-key",
).encode("utf-8")

_GATEWAY_MINT_CAPABILITY = object()

@dataclass(frozen=True)
class ExecutionPermit:
    authority_receipt_id: str
    action_binding_hash: str
    authority_state_version: int
    issued_at: str
    signature: str
    valid_until: str | None = None
    execution_path_binding_hash: str | None = None
    capability_context_binding_hash: str | None = None
    execution_path_generation: int | None = None
    capability_context_generation: int | None = None
    authority_context_epoch: int | None = None
    capacity_reservation_id: str | None = None
    capacity_key_id: str | None = None
    capacity_store_version: int | None = None

def _payload(authority_receipt_id, action_binding_hash, authority_state_version, issued_at, valid_until,
             execution_path_binding_hash=None, capability_context_binding_hash=None,
             execution_path_generation=None, capability_context_generation=None, authority_context_epoch=None,
             capacity_reservation_id=None, capacity_key_id=None, capacity_store_version=None) -> bytes:
    payload = {
        "authority_receipt_id": authority_receipt_id,
        "action_binding_hash": action_binding_hash,
        "authority_state_version": authority_state_version,
        "issued_at": issued_at,
        "valid_until": valid_until,
        "execution_path_binding_hash": execution_path_binding_hash,
        "capability_context_binding_hash": capability_context_binding_hash,
        "execution_path_generation": execution_path_generation,
        "capability_context_generation": capability_context_generation,
        "authority_context_epoch": authority_context_epoch,
    }
    # Preserve verification of permits minted before capacity binding existed.
    if capacity_reservation_id is not None:
        payload.update({
            "capacity_reservation_id": capacity_reservation_id,
            "capacity_key_id": capacity_key_id,
            "capacity_store_version": capacity_store_version,
        })
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")

def _sign(authority_receipt_id, action_binding_hash, authority_state_version, issued_at, valid_until,
          execution_path_binding_hash=None, capability_context_binding_hash=None,
          execution_path_generation=None, capability_context_generation=None, authority_context_epoch=None,
          capacity_reservation_id=None, capacity_key_id=None, capacity_store_version=None) -> str:
    return hmac.new(_PERMIT_KEY, _payload(
        authority_receipt_id, action_binding_hash, authority_state_version, issued_at, valid_until,
        execution_path_binding_hash, capability_context_binding_hash,
        execution_path_generation, capability_context_generation, authority_context_epoch,
        capacity_reservation_id, capacity_key_id, capacity_store_version,
    ), hashlib.sha256).hexdigest()

def issue_execution_permit(authority_receipt_id, action_binding_hash, authority_state_version, *,
                           valid_until=None, mint_capability=None,
                           execution_path_binding_hash=None, capability_context_binding_hash=None,
                           execution_path_generation=None, capability_context_generation=None,
                           expected_authority_context_epoch=None, capacity_reservation_id=None,
                           capacity_key_id=None, capacity_store_version=None):
    if mint_capability is not _GATEWAY_MINT_CAPABILITY or valid_until is None:
        return None
    if expected_authority_context_epoch is not None and current_authority_context_epoch() != expected_authority_context_epoch:
        return None
    issued_at = datetime.now(timezone.utc).isoformat()
    return ExecutionPermit(
        authority_receipt_id=authority_receipt_id,
        action_binding_hash=action_binding_hash,
        authority_state_version=authority_state_version,
        issued_at=issued_at,
        valid_until=valid_until,
        execution_path_binding_hash=execution_path_binding_hash,
        capability_context_binding_hash=capability_context_binding_hash,
        execution_path_generation=execution_path_generation,
        capability_context_generation=capability_context_generation,
        authority_context_epoch=expected_authority_context_epoch,
        capacity_reservation_id=capacity_reservation_id,
        capacity_key_id=capacity_key_id,
        capacity_store_version=capacity_store_version,
        signature=_sign(authority_receipt_id, action_binding_hash, authority_state_version, issued_at, valid_until,
                        execution_path_binding_hash, capability_context_binding_hash,
                        execution_path_generation, capability_context_generation, expected_authority_context_epoch,
                        capacity_reservation_id, capacity_key_id, capacity_store_version),
    )

def verify_execution_permit(permit: ExecutionPermit) -> bool:
    expected = _sign(
        permit.authority_receipt_id, permit.action_binding_hash, permit.authority_state_version,
        permit.issued_at, permit.valid_until, permit.execution_path_binding_hash,
        permit.capability_context_binding_hash, permit.execution_path_generation,
        permit.capability_context_generation, permit.authority_context_epoch,
        permit.capacity_reservation_id, permit.capacity_key_id, permit.capacity_store_version,
    )
    return hmac.compare_digest(expected, permit.signature)
