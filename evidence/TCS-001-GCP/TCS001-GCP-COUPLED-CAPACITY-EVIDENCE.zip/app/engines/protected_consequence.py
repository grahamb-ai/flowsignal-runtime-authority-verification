from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from typing import Callable

from app.engines.authority_store import (
    authority_state_guard,
    get_authority_state_version_unlocked,
)
from app.engines.consequence_outcome_store import record_consequence_outcome as _record_consequence_outcome
from app.engines.consequence_receipt import (
    ConsequenceOutcomeReceipt,
    create_consequence_outcome_receipt,
)
from app.engines.permit_authority import ExecutionPermit, verify_execution_permit
from app.engines.authority_context_epoch import current_authority_context_epoch, commit_consequence_if_current
from app.engines.capability_context_store import CapabilityContextUnavailable, get_capability_context_snapshot
from app.engines.execution_path_store import ExecutionPathAuthorityUnavailable, get_execution_path_snapshot
from app.engines.execution_path_authority import execution_path_binding_hash
from app.engines.permit_consumption_store import consume_execution_permit_and_begin_outcome_once
from app.engines.rollback_anchor_store import claim_execution_anchor_once


def record_consequence_outcome(*, permit_signature: str, action_binding_hash: str, outcome: str, expected_authority_context_epoch: int | None = None):
    """Protected consequence recorder; formation is authority-owned when epoch-bound."""
    if outcome == "CONSEQUENCE_FORMED" and expected_authority_context_epoch is not None:
        return commit_consequence_if_current(
            expected_authority_context_epoch,
            permit_signature=permit_signature,
            action_binding_hash=action_binding_hash,
        )
    _record_consequence_outcome(
        permit_signature=permit_signature,
        action_binding_hash=action_binding_hash,
        outcome=outcome,
    )
    return True


def _capability_context_binding(capabilities) -> str:
    raw = json.dumps(sorted(capabilities), separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _aware(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def execute_protected_consequence(
    permit: ExecutionPermit | None,
    attempted_action_binding_hash: str,
    *,
    before_formation_hook: Callable[[], None] | None = None,
    executing_path_binding_hash: str | None = None,
) -> str:
    """Consume, but do not mint, a consequence-authorising execution permit.

    Permit issuance/signing lives in the separate reference permit-authority
    component. This represented execution component verifies the permit, checks
    exact action binding and temporal/current-state standing, and establishes
    durable permit consumption together with an initial unresolved execution
    outcome before entering the remaining consequence-formation interval.

    PMQ-002.9 commits permit consumption and CONSEQUENCE_OUTCOME_UNRESOLVED
    together through one attached-database transaction.

    PMQ-002.10 adds a separate surviving rollback anchor. Ordinary replay remains
    distinguishable from rollback: if the anchor already exists and the durable
    permit store also reports the permit consumed, the result remains the prior
    DENIED_EXECUTION_PERMIT_REPLAY. If the anchor already exists but the restored
    execution-state stores accept the permit as apparently unused, execution is
    stopped as DENIED_EXECUTION_STATE_ROLLBACK_OR_REPLAY before consequence
    formation.

    This is a reference-MVP local SQLite boundary. The rollback anchor only
    demonstrates detection when that separate anchor survives rollback of the
    permit-consumption and consequence-outcome stores. It is not claimed as
    resistance to rollback of all local state, production distributed
    transactionality, database HA, cross-host atomicity, fsync/power-loss
    durability, immutable/write-once audit, external payment idempotency or
    production process/IAM/KMS/HSM isolation.
    """
    if permit is None:
        return "DENIED_NO_EXECUTION_PERMIT"

    if not verify_execution_permit(permit):
        return "DENIED_INVALID_EXECUTION_PERMIT"

    if permit.action_binding_hash != attempted_action_binding_hash:
        return "DENIED_ACTION_BINDING_MISMATCH"

    # A permit is only exercisable while the shared authoritative context is
    # still the epoch under which the permit was minted.
    if permit.authority_context_epoch is not None and current_authority_context_epoch() != permit.authority_context_epoch:
        return "DENIED_AUTHORITY_CONTEXT_EPOCH_CHANGED_REEVALUATION_REQUIRED"

    if permit.capability_context_binding_hash is not None:
        try:
            capability_snapshot = get_capability_context_snapshot()
            current_capabilities = capability_snapshot.capabilities
        except CapabilityContextUnavailable:
            return "DENIED_CAPABILITY_CONTEXT_UNAVAILABLE"
        if _capability_context_binding(current_capabilities) != permit.capability_context_binding_hash:
            return "DENIED_CAPABILITY_CONTEXT_CHANGED_REEVALUATION_REQUIRED"
        if permit.capability_context_generation is not None and capability_snapshot.generation != permit.capability_context_generation:
            return "DENIED_CAPABILITY_CONTEXT_GENERATION_CHANGED_REEVALUATION_REQUIRED"

    if permit.execution_path_binding_hash is not None:
        if executing_path_binding_hash is None:
            return "DENIED_EXECUTION_PATH_CONTEXT_MISSING"
        if permit.execution_path_binding_hash != executing_path_binding_hash:
            return "DENIED_EXECUTION_PATH_BINDING_MISMATCH"
        if permit.execution_path_generation is not None:
            try:
                path_snapshot = get_execution_path_snapshot()
            except ExecutionPathAuthorityUnavailable:
                return "DENIED_EXECUTION_PATH_AUTHORITY_UNAVAILABLE"
            if execution_path_binding_hash(path_snapshot.authority) != permit.execution_path_binding_hash:
                return "DENIED_EXECUTION_PATH_BINDING_MISMATCH"
            if path_snapshot.generation != permit.execution_path_generation:
                return "DENIED_EXECUTION_PATH_GENERATION_CHANGED_REEVALUATION_REQUIRED"

    if permit.valid_until is None:
        return "DENIED_EXECUTION_PERMIT_EXPIRY_MISSING"

    try:
        permit_expiry = _aware(datetime.fromisoformat(permit.valid_until))
    except (TypeError, ValueError):
        return "DENIED_EXECUTION_PERMIT_EXPIRY_INVALID"

    if datetime.now(timezone.utc) > permit_expiry:
        return "DENIED_EXECUTION_PERMIT_EXPIRED"

    with authority_state_guard():
        if datetime.now(timezone.utc) > permit_expiry:
            return "DENIED_EXECUTION_PERMIT_EXPIRED"

        current_authority_state_version = get_authority_state_version_unlocked()
        if permit.authority_state_version != current_authority_state_version:
            return "DENIED_AUTHORITY_STATE_STALE"

        consumption_identity = permit.capacity_reservation_id or permit.signature
        anchor_was_new = claim_execution_anchor_once(
            permit_signature=consumption_identity,
            action_binding_hash=attempted_action_binding_hash,
        )

        consumption_was_new = consume_execution_permit_and_begin_outcome_once(
            consumption_identity,
            attempted_action_binding_hash,
        )

        if not consumption_was_new:
            return "DENIED_EXECUTION_PERMIT_REPLAY"

        if not anchor_was_new:
            # The separate anchor remembers this execution while the restored
            # execution-state stores have accepted it as new. The consumption
            # transaction has safely re-established an unresolved record, but
            # represented consequence formation must stop here.
            return "DENIED_EXECUTION_STATE_ROLLBACK_OR_REPLAY"

        # The external/represented formation hook is deliberately outside any
        # authority-context lock. It may change standing, but it cannot itself
        # commit the consequence. After it returns, the authority boundary owns
        # the final commit decision and revalidates current standing.
        if before_formation_hook is not None:
            try:
                before_formation_hook()
            except Exception:
                record_consequence_outcome(
                    permit_signature=consumption_identity,
                    action_binding_hash=attempted_action_binding_hash,
                    outcome="CONSEQUENCE_NOT_FORMED",
                )
                raise

        if permit.authority_context_epoch is not None:
            committed = record_consequence_outcome(
                permit_signature=consumption_identity,
                action_binding_hash=attempted_action_binding_hash,
                outcome="CONSEQUENCE_FORMED",
                expected_authority_context_epoch=permit.authority_context_epoch,
            )
            if not committed:
                record_consequence_outcome(
                    permit_signature=consumption_identity,
                    action_binding_hash=attempted_action_binding_hash,
                    outcome="CONSEQUENCE_NOT_FORMED",
                )
                return "DENIED_AUTHORITY_CONTEXT_CHANGED_BEFORE_CONSEQUENCE_COMMIT"
            return "CONSEQUENCE_FORMED"

        record_consequence_outcome(
            permit_signature=consumption_identity,
            action_binding_hash=attempted_action_binding_hash,
            outcome="CONSEQUENCE_FORMED",
        )
        return "CONSEQUENCE_FORMED"


def execute_protected_consequence_with_receipt(
    permit: ExecutionPermit | None,
    attempted_action_binding_hash: str,
    *,
    before_formation_hook: Callable[[], None] | None = None,
    executing_path_binding_hash: str | None = None,
) -> tuple[str, ConsequenceOutcomeReceipt]:
    outcome = execute_protected_consequence(
        permit=permit,
        attempted_action_binding_hash=attempted_action_binding_hash,
        before_formation_hook=before_formation_hook,
        executing_path_binding_hash=executing_path_binding_hash,
    )
    receipt = create_consequence_outcome_receipt(
        authority_receipt_id=(permit.authority_receipt_id if permit is not None else None),
        action_binding_hash=attempted_action_binding_hash,
        authority_state_version=(permit.authority_state_version if permit is not None else None),
        outcome=outcome,
    )
    return outcome, receipt
