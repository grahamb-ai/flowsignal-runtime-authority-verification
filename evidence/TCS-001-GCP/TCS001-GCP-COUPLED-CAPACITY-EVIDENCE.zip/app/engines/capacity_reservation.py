from __future__ import annotations

import hashlib
import json
import os
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from threading import RLock
from typing import Protocol


class CapacityStoreUnavailable(RuntimeError):
    pass


@dataclass(frozen=True)
class CapacityKey:
    authority_id: str
    principal_id: str
    source_account: str
    currency: str
    window_id: str

    @property
    def canonical_id(self) -> str:
        raw = json.dumps(asdict(self), sort_keys=True, separators=(",", ":")).encode()
        return hashlib.sha256(raw).hexdigest()


@dataclass(frozen=True)
class CapacityReservation:
    status: str
    reason_code: str
    execution_id: str
    reservation_id: str | None
    amount: float
    capacity_limit: float
    reserved_before: float
    reserved_after: float
    key_id: str
    store_version: int


class CapacityReservationStore(Protocol):
    def reserve(
        self,
        *,
        key: CapacityKey,
        execution_id: str,
        amount: float,
        capacity_limit: float,
    ) -> CapacityReservation: ...


def _validate(amount: float, capacity_limit: float, execution_id: str) -> None:
    if not execution_id.strip():
        raise ValueError("execution_id must be nonblank")
    if amount <= 0:
        raise ValueError("amount must be positive")
    if capacity_limit < 0:
        raise ValueError("capacity_limit must be non-negative")


def _reservation_id(key: CapacityKey, execution_id: str) -> str:
    raw = f"{key.canonical_id}:{execution_id}".encode()
    return hashlib.sha256(raw).hexdigest()


class InMemoryCapacityReservationStore:
    """Deterministic test/reference store; not a cross-instance backend."""

    def __init__(self) -> None:
        self._lock = RLock()
        self._totals: dict[str, float] = {}
        self._versions: dict[str, int] = {}
        self._reservations: dict[tuple[str, str], tuple[float, float, str]] = {}

    def reserve(self, *, key, execution_id, amount, capacity_limit) -> CapacityReservation:
        _validate(amount, capacity_limit, execution_id)
        key_id = key.canonical_id
        reservation_key = (key_id, execution_id)
        with self._lock:
            existing = self._reservations.get(reservation_key)
            total = self._totals.get(key_id, 0.0)
            version = self._versions.get(key_id, 0)
            if existing is not None:
                old_amount, old_limit, rid = existing
                if old_amount != amount or old_limit != capacity_limit:
                    return CapacityReservation(
                        "REFUSE", "EXECUTION_ID_CONFLICT", execution_id, rid, amount,
                        capacity_limit, total, total, key_id, version,
                    )
                return CapacityReservation(
                    "RESERVED", "CAPACITY_RESERVATION_IDEMPOTENT", execution_id, rid,
                    amount, capacity_limit, total - amount, total, key_id, version,
                )
            if total + amount > capacity_limit:
                return CapacityReservation(
                    "REFUSE", "COUPLED_CAPACITY_EXCEEDED", execution_id, None, amount,
                    capacity_limit, total, total, key_id, version,
                )
            rid = _reservation_id(key, execution_id)
            updated = total + amount
            version += 1
            self._reservations[reservation_key] = (amount, capacity_limit, rid)
            self._totals[key_id] = updated
            self._versions[key_id] = version
            return CapacityReservation(
                "RESERVED", "COUPLED_CAPACITY_RESERVED", execution_id, rid, amount,
                capacity_limit, total, updated, key_id, version,
            )


class FirestoreCapacityReservationStore:
    """Cross-instance atomic reservation store backed by Firestore transactions."""

    def __init__(self, *, project: str | None = None, database: str | None = None) -> None:
        try:
            from google.cloud import firestore
        except ImportError as exc:
            raise CapacityStoreUnavailable(
                "Firestore backend selected but google-cloud-firestore is not installed"
            ) from exc
        kwargs = {}
        if project:
            kwargs["project"] = project
        if database:
            kwargs["database"] = database
        self._firestore = firestore
        self._client = firestore.Client(**kwargs)
        self._collection = os.getenv("FLOWSIGNAL_CAPACITY_COLLECTION", "authority_capacity")

    def reserve(self, *, key, execution_id, amount, capacity_limit) -> CapacityReservation:
        _validate(amount, capacity_limit, execution_id)
        firestore = self._firestore
        key_id = key.canonical_id
        aggregate = self._client.collection(self._collection).document(key_id)
        rid = _reservation_id(key, execution_id)
        reservation = aggregate.collection("reservations").document(rid)
        transaction = self._client.transaction()

        @firestore.transactional
        def transact(tx):
            existing_snapshot = reservation.get(transaction=tx)
            aggregate_snapshot = aggregate.get(transaction=tx)
            aggregate_data = aggregate_snapshot.to_dict() or {}
            total = float(aggregate_data.get("reserved_total", 0.0))
            version = int(aggregate_data.get("version", 0))
            if existing_snapshot.exists:
                existing = existing_snapshot.to_dict() or {}
                if (float(existing.get("amount", -1)) != amount or
                        float(existing.get("capacity_limit", -1)) != capacity_limit):
                    return CapacityReservation(
                        "REFUSE", "EXECUTION_ID_CONFLICT", execution_id, rid, amount,
                        capacity_limit, total, total, key_id, version,
                    )
                return CapacityReservation(
                    "RESERVED", "CAPACITY_RESERVATION_IDEMPOTENT", execution_id, rid,
                    amount, capacity_limit, total - amount, total, key_id, version,
                )
            if total + amount > capacity_limit:
                return CapacityReservation(
                    "REFUSE", "COUPLED_CAPACITY_EXCEEDED", execution_id, None, amount,
                    capacity_limit, total, total, key_id, version,
                )
            updated = total + amount
            version += 1
            now = datetime.now(timezone.utc)
            tx.set(aggregate, {
                **asdict(key), "reserved_total": updated, "capacity_limit": capacity_limit,
                "version": version, "updated_at": now,
            })
            tx.create(reservation, {
                "execution_id": execution_id, "amount": amount,
                "capacity_limit": capacity_limit, "reserved_at": now,
            })
            return CapacityReservation(
                "RESERVED", "COUPLED_CAPACITY_RESERVED", execution_id, rid, amount,
                capacity_limit, total, updated, key_id, version,
            )

        return transact(transaction)


_TEST_STORE = InMemoryCapacityReservationStore()


def configured_capacity_store() -> CapacityReservationStore:
    backend = os.getenv("FLOWSIGNAL_CAPACITY_BACKEND", "").strip().lower()
    if backend == "firestore":
        return FirestoreCapacityReservationStore(
            project=os.getenv("GOOGLE_CLOUD_PROJECT") or None,
            database=os.getenv("FLOWSIGNAL_CAPACITY_FIRESTORE_DATABASE") or None,
        )
    if backend == "memory":
        return _TEST_STORE
    raise CapacityStoreUnavailable(
        "No capacity backend configured; set FLOWSIGNAL_CAPACITY_BACKEND=firestore "
        "for Cloud Run or =memory only for local tests"
    )
