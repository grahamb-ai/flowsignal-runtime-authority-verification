from __future__ import annotations

from dataclasses import asdict, replace
from datetime import datetime
from typing import Any

from fastapi import Depends, FastAPI, HTTPException
from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.cage_auth import require_cage_bearer
from app.cage_contract import map_flowsignal_to_cage
from app.engines.delegated_authority import evaluate_delegated_authority
from app.engines.financial_types import FinancialAuthorityRequest
from app.engines.execution_path_authority import execution_path_binding_hash, verify_execution_path_attestation
from app.engines.execution_path_store import ExecutionPathAuthorityUnavailable, get_execution_path_snapshot
from app.engines.receipt_integrity import compute_receipt_hmac
from app.engines.authority_store import get_authority_record
from app.engines.capacity_reservation import CapacityKey, CapacityStoreUnavailable, configured_capacity_store
from app.engines.permit_authority import _GATEWAY_MINT_CAPABILITY, issue_execution_permit


app = FastAPI(
    title="FlowSignal Runtime Authority vNext",
    version="0.1-private",
    description=(
        "Reference service boundary for independent delegated-authority "
        "determination before consequential execution."
    ),
)


class AuthorityDetermineRequest(BaseModel):
    approval_id: str
    platform: str
    execution_id: str

    scenario_id: str
    action: str
    target: str
    actor_id: str
    actor_type: str
    actor_role: str
    actor_authenticated: bool
    kya_status: str
    principal_id: str
    principal_name: str
    mandate_id: str
    mandate_status: str = Field(
        description=(
            "Caller-presented mandate status. This is preserved as evidence but "
            "is not treated as authoritative authority state."
        )
    )
    mandate_max_amount: float
    mandate_currency: str
    permitted_source_accounts: list[str]
    permitted_counterparty_class: str
    mandate_valid_until: datetime
    amount: float
    currency: str
    source_account: str
    beneficiary: str
    purpose: str
    counterparty_status: str
    account_status: str
    risk_state: str
    approval_required: bool
    screening_status: str
    screening_captured_at: datetime
    screening_max_age_seconds: int
    screening_source: str
    requested_execution_time: datetime

    authority_resolution_path: str | None = None
    evidence_references: list[dict[str, Any]] = Field(default_factory=list)


class CageAuthorityDetermineRequest(BaseModel):
    """CAGE v3-facing request model.

    CAGE generalises finance-specific fields as amount -> magnitude and
    symbol -> context. FlowSignal keeps its native amount/currency contract
    separate from this external wire vocabulary.
    """

    model_config = ConfigDict(extra="forbid")

    approval_id: str
    platform: str
    execution_id: str
    scenario_id: str
    action: str
    target: str
    actor_id: str
    actor_type: str
    actor_role: str
    actor_authenticated: bool
    kya_status: str
    principal_id: str
    principal_name: str
    mandate_id: str
    mandate_status: str
    mandate_max_amount: float
    mandate_currency: str
    permitted_source_accounts: list[str]
    permitted_counterparty_class: str
    mandate_valid_until: datetime
    magnitude: float
    context: str
    currency: str
    source_account: str
    beneficiary: str
    purpose: str
    counterparty_status: str
    account_status: str
    risk_state: str
    approval_required: bool
    screening_status: str
    screening_captured_at: datetime
    screening_max_age_seconds: int
    screening_source: str
    requested_execution_time: datetime
    authority_resolution_path: str | None = None
    evidence_references: list[dict[str, Any]] = Field(default_factory=list)

    @field_validator("platform", "execution_id")
    @classmethod
    def validate_correlation_identity(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("CAGE correlation identity must be nonblank")
        return value


class AuthorityDetermineResponse(BaseModel):
    determination: str
    reason_code: str
    required_action: str | None
    authority_receipt: dict[str, Any]
    execution_context: dict[str, str]


class AuthorityFinalBindResponse(BaseModel):
    decision: str
    reason_code: str
    authority_receipt: dict[str, Any]
    capacity_reservation: dict[str, Any] | None
    execution_permit: dict[str, Any] | None
    execution_context: dict[str, str]


class CageFindingResponse(BaseModel):
    code: str
    message: str
    needs_human_review: bool


class CageValidationResponse(BaseModel):
    decision: str
    authority_record_id: str | None
    findings: list[CageFindingResponse]
    authority_receipt: dict[str, Any]
    execution_context: dict[str, str]


def _request_from_payload(payload: AuthorityDetermineRequest) -> FinancialAuthorityRequest:
    request_fields = payload.model_dump(
        exclude={
            "approval_id",
            "platform",
            "execution_id",
            "authority_resolution_path",
            "evidence_references",
        }
    )
    return FinancialAuthorityRequest(**request_fields)


def _native_request_from_cage(payload: CageAuthorityDetermineRequest) -> AuthorityDetermineRequest:
    data = payload.model_dump(exclude={"magnitude", "context"})
    data["amount"] = payload.magnitude
    return AuthorityDetermineRequest(**data)


def _determine(payload: AuthorityDetermineRequest):
    request = _request_from_payload(payload)
    response, receipt = evaluate_delegated_authority(
        request,
        approval_id=payload.approval_id,
        authority_resolution_path=payload.authority_resolution_path,
    )
    receipt_payload = asdict(receipt)
    if payload.evidence_references:
        # Caller evidence is intentionally not merged into the sealed receipt.
        # It remains presented context until independently verified.
        receipt_payload["presented_evidence_references"] = payload.evidence_references
    return response, receipt_payload


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "runtime-authority-vnext"}


@app.post("/authority/determine", response_model=AuthorityDetermineResponse)
def determine_authority(payload: AuthorityDetermineRequest) -> AuthorityDetermineResponse:
    """Native FlowSignal authority contract; no consequence-execution capability."""
    response, receipt_payload = _determine(payload)
    return AuthorityDetermineResponse(
        determination=response.decision,
        reason_code=response.reason_code,
        required_action=response.required_action,
        authority_receipt=receipt_payload,
        execution_context={
            "platform": payload.platform,
            "execution_id": payload.execution_id,
        },
    )


@app.post("/authority/final-bind", response_model=AuthorityFinalBindResponse)
def final_bind_authority(
    payload: AuthorityDetermineRequest,
    _authenticated: None = Depends(require_cage_bearer),
) -> AuthorityFinalBindResponse:
    """Atomically reserve shared capacity before minting an execution permit.

    Determination remains side-effect free. Cloud Run must configure a durable
    shared backend; missing capacity state fails closed.
    """
    request = _request_from_payload(payload)
    response, receipt = evaluate_delegated_authority(
        request,
        approval_id=payload.approval_id,
        authority_resolution_path=payload.authority_resolution_path,
    )
    receipt_payload = asdict(receipt)
    context = {"platform": payload.platform, "execution_id": payload.execution_id}
    if response.decision != "ALLOW":
        return AuthorityFinalBindResponse(
            decision=response.decision,
            reason_code=response.reason_code,
            authority_receipt=receipt_payload,
            capacity_reservation=None,
            execution_permit=None,
            execution_context=context,
        )

    authority = get_authority_record(payload.mandate_id)
    if authority is None or authority.max_amount is None:
        return AuthorityFinalBindResponse(
            decision="REFUSE",
            reason_code="AUTHORITATIVE_CAPACITY_UNAVAILABLE",
            authority_receipt=receipt_payload,
            capacity_reservation=None,
            execution_permit=None,
            execution_context=context,
        )

    window_id = ":".join((
        str(authority.version),
        authority.effective_from.isoformat() if authority.effective_from else "unbounded-start",
        authority.effective_until.isoformat() if authority.effective_until else "unbounded-end",
    ))
    key = CapacityKey(
        authority_id=authority.authority_id,
        principal_id=authority.principal_id,
        source_account=payload.source_account,
        currency=payload.currency.upper(),
        window_id=window_id,
    )
    try:
        reservation = configured_capacity_store().reserve(
            key=key,
            execution_id=payload.execution_id,
            amount=payload.amount,
            capacity_limit=authority.max_amount,
        )
    except CapacityStoreUnavailable as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    reservation_payload = asdict(reservation)
    if reservation.status != "RESERVED":
        return AuthorityFinalBindResponse(
            decision="REFUSE",
            reason_code=reservation.reason_code,
            authority_receipt=receipt_payload,
            capacity_reservation=reservation_payload,
            execution_permit=None,
            execution_context=context,
        )

    permit = issue_execution_permit(
        authority_receipt_id=receipt.id,
        action_binding_hash=receipt.action_binding_hash,
        authority_state_version=receipt.authority_state_version,
        valid_until=receipt.valid_until.isoformat(),
        mint_capability=_GATEWAY_MINT_CAPABILITY,
        capacity_reservation_id=reservation.reservation_id,
        capacity_key_id=reservation.key_id,
        capacity_store_version=reservation.store_version,
    )
    return AuthorityFinalBindResponse(
        decision="ALLOW",
        reason_code=reservation.reason_code,
        authority_receipt=receipt_payload,
        capacity_reservation=reservation_payload,
        execution_permit=asdict(permit) if permit is not None else None,
        execution_context=context,
    )


@app.post("/cage/validate", response_model=CageValidationResponse)
def validate_for_cage(
    payload: CageAuthorityDetermineRequest,
    _authenticated: None = Depends(require_cage_bearer),
) -> CageValidationResponse:
    """CAGE-facing adapter contract.

    Phase 3 staging protects this path with CAGE's application-level Bearer
    credential. ESCALATE is returned as a ValidationResult HOLD finding rather
    than raised as an exception. ALLOW always carries decision and
    authority_record_id. REFUSE remains an explicit non-authorising result.
    FlowSignal determines only; CAGE remains responsible for enforcement and
    consequence routing.
    """
    native_payload = _native_request_from_cage(payload)
    response, receipt_payload = _determine(native_payload)
    # The frozen 37-field wire contains no execution route or executor.
    # Determination does not assert that a downstream route is authorised.
    # Preserve the authority-owned receipt exactly as formed and sealed by
    # _determine(). CAGE independently enforces its actual execution clearance
    # at ConsequenceGateway / actuator dispatch; the internal Phase 4 path
    # checks remain in the protected-consequence harness, not this wire API.
    mapped = map_flowsignal_to_cage(
        decision=response.decision,
        reason_code=response.reason_code,
        required_action=response.required_action,
        receipt_payload=receipt_payload,
        platform=payload.platform,
        execution_id=payload.execution_id,
    )
    return CageValidationResponse(
        decision=mapped.decision,
        authority_record_id=mapped.authority_record_id,
        findings=[CageFindingResponse(**asdict(item)) for item in mapped.findings],
        authority_receipt=mapped.authority_receipt,
        execution_context=mapped.execution_context,
    )
