# TCS-001 coupled-capacity remediation candidate

## Frozen input

- Source image digest: `sha256:d681fd2df24f4585ac40c43a76c1eb73ffb7bdb7611f67d4ba2a717cd43d951d`
- Uploaded source archive SHA-256: `264d70126ecf93a30b6f6bbd0ef1c0314428873865b1c34a81f95eb1a9d63802`
- Deployed revision tested: `flowsignal-cage-phase4-staging-00001-8nr`

The preserved scaled test is mathematically equivalent to capacity 10 with two
burdens of 6. The deployed authoritative limit is 1,000,000, so the requests
used 600,000 and 600,000.

## First deployed RED (before remediation)

The side-effect-free `/authority/determine` endpoint returned ALLOW for A and B
independently, while a synthetic combined request returned ESCALATE. This
demonstrated that the deployed determination boundary did not aggregate active
burden across separate executions. It did not demonstrate that two external
consequences formed.

Request hashes:

- A: `dd31a58a3a9ac883297d10a5a95caff344502c83f01b9905e1697c2b38221461`
- B: `4b5e8dc4dbac4d34251e892c4eac230a90cd25884cd20e571fe6aa05eeed5225`
- combined: `cf549754fe145880c0c82ae19dc071630d7303f5523cdde9e61309d4d2989433`

Response hashes:

- A: `0bd4fa69d511bbeb46e096fbeeced26a7a66ad3297c49ecf1dd481c71674bcf8`
- B: `5bb9a1d82145e33722d73150e01b8c40b5be31150b7894f98a9f92fe33716464`
- combined: `3bd8b09e07c675f3667fe86e893247f054a2b8d3c35393c3a5cdfdf0d6cfcf75`

## Candidate behavior

- `/authority/determine` remains side-effect free.
- `/authority/final-bind` re-evaluates authority, reserves shared capacity in
  one atomic transaction, and only then mints a capacity-bound permit.
- The key is authority, principal, source account, currency, and authority
  validity/version window.
- The authoritative record supplies the limit; the caller does not.
- `execution_id` provides idempotency. Reuse with changed amount or limit is
  refused.
- The reservation ID becomes the permit-consumption identity, preventing an
  idempotent remint from forming a second consequence.
- Cloud Run fails closed unless `FLOWSIGNAL_CAPACITY_BACKEND=firestore` is set.
- The in-memory backend is test-only and must not be used across Cloud Run
  instances.

## Tests executed in this candidate

Five standard-library regression tests pass:

1. Exact 10 / 6 / 6 challenge: first reserves; second refuses.
2. Scaled 1,000,000 / 600,000 / 600,000 case: second refuses.
3. Same execution retry is idempotent and does not double reserve.
4. Same execution ID with changed amount refuses.
5. Concurrent 6 + 6 attempts cannot both reserve against 10.

All shipped Python compiles. AP-001 through AP-005 execute. AP-006 now creates
its previously missing output directory and executes. The source archive did
not contain the original pytest suite or container build files, so this result
does not claim that an omitted full suite or container build passed.

## Deployment gate

Do not replace the live revision yet. Before deployment:

1. Review and run the candidate in the canonical repository with its full tests.
2. Enable Firestore and create the selected database/location.
3. Grant the Cloud Run runtime service account only the required document
   transaction permissions.
4. Set `FLOWSIGNAL_CAPACITY_BACKEND=firestore` and the database setting.
5. Deploy a new revision with no traffic, run the frozen TCS-001 requests
   against `/authority/final-bind`, and preserve request/response hashes.
6. Verify one RESERVED/ALLOW and one `COUPLED_CAPACITY_EXCEEDED`/REFUSE under
   both sequential and concurrent execution.
7. Verify an idempotent retry cannot form a second protected consequence.
8. Shift traffic only after the full suite and rollback checks pass.

This is a remediation candidate, not evidence of a production deployment.
