from __future__ import annotations

from copy import deepcopy

from fastapi.testclient import TestClient

from app.api import app


BASE = {
    "approval_id": "APPROVAL-TREASURY-001",
    "platform": "TCS-001-CONTAINER-TEST",
    "execution_id": "TCS-001-A",
    "scenario_id": "TCS-001-A",
    "action": "payment.release",
    "target": "TREASURY_PAYMENT_GATEWAY",
    "actor_id": "agent-treasury-01",
    "actor_type": "autonomous_agent",
    "actor_role": "treasury_agent",
    "actor_authenticated": True,
    "kya_status": "VERIFIED",
    "principal_id": "institution-001",
    "principal_name": "Example Financial Institution",
    "mandate_id": "MANDATE-TREASURY-001",
    "mandate_status": "ACTIVE",
    "mandate_max_amount": 1_000_000,
    "mandate_currency": "GBP",
    "permitted_source_accounts": ["TREASURY-001"],
    "permitted_counterparty_class": "APPROVED_SUPPLIERS",
    "mandate_valid_until": "2026-12-31T23:59:59Z",
    "amount": 600_000,
    "currency": "GBP",
    "source_account": "TREASURY-001",
    "beneficiary": "SUPPLIER-X",
    "purpose": "TCS-001 coupled-capacity test",
    "counterparty_status": "APPROVED",
    "account_status": "ACTIVE",
    "risk_state": "NORMAL",
    "approval_required": False,
    "screening_status": "CLEAR",
    "screening_captured_at": "2026-10-10T13:45:00Z",
    "screening_max_age_seconds": 3600,
    "screening_source": "TCS-001-STAGING-EVIDENCE",
    "requested_execution_time": "2026-10-10T14:00:00Z",
}


def test_tcs001_determination_is_non_consuming_but_final_bind_refuses_second_burden(monkeypatch):
    monkeypatch.setenv("FLOWSIGNAL_CAGE_BEARER_REQUIRED", "true")
    monkeypatch.setenv("FLOWSIGNAL_CAGE_BEARER_TOKEN", "tcs001-test-token")
    monkeypatch.setenv("FLOWSIGNAL_CAPACITY_BACKEND", "memory")
    headers = {"Authorization": "Bearer tcs001-test-token"}
    client = TestClient(app)

    movement_a = deepcopy(BASE)
    movement_b = deepcopy(BASE)
    movement_b["execution_id"] = movement_b["scenario_id"] = "TCS-001-B"

    # Determination remains intentionally non-consuming.
    assert client.post("/authority/determine", json=movement_a).json()["determination"] == "ALLOW"
    assert client.post("/authority/determine", json=movement_b).json()["determination"] == "ALLOW"

    first = client.post("/authority/final-bind", json=movement_a, headers=headers)
    second = client.post("/authority/final-bind", json=movement_b, headers=headers)

    assert first.status_code == 200
    assert first.json()["decision"] == "ALLOW"
    assert first.json()["capacity_reservation"]["reserved_after"] == 600_000
    assert first.json()["execution_permit"]["capacity_reservation_id"]

    assert second.status_code == 200
    assert second.json()["decision"] == "REFUSE"
    assert second.json()["reason_code"] == "COUPLED_CAPACITY_EXCEEDED"
    assert second.json()["capacity_reservation"]["reserved_after"] == 600_000
    assert second.json()["execution_permit"] is None
