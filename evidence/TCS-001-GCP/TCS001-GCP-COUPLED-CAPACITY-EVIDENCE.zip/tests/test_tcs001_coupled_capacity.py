from __future__ import annotations

import threading
import unittest

from app.engines.capacity_reservation import CapacityKey, InMemoryCapacityReservationStore


KEY = CapacityKey(
    authority_id="MANDATE-TREASURY-001",
    principal_id="institution-001",
    source_account="GB00-FLOWSIGNAL-OPERATING",
    currency="GBP",
    window_id="authority-v1",
)


class TCS001CoupledCapacityTest(unittest.TestCase):
    def setUp(self):
        self.store = InMemoryCapacityReservationStore()

    def test_exact_terry_challenge_refuses_second_six_against_shared_ten(self):
        first = self.store.reserve(key=KEY, execution_id="movement-A", amount=6, capacity_limit=10)
        second = self.store.reserve(key=KEY, execution_id="movement-B", amount=6, capacity_limit=10)
        self.assertEqual((first.status, first.reserved_after), ("RESERVED", 6))
        self.assertEqual(second.status, "REFUSE")
        self.assertEqual(second.reason_code, "COUPLED_CAPACITY_EXCEEDED")
        self.assertEqual((second.reserved_before, second.reserved_after), (6, 6))

    def test_scaled_deployed_case_refuses_second_600k_against_shared_1m(self):
        first = self.store.reserve(key=KEY, execution_id="scaled-A", amount=600_000, capacity_limit=1_000_000)
        second = self.store.reserve(key=KEY, execution_id="scaled-B", amount=600_000, capacity_limit=1_000_000)
        self.assertEqual(first.status, "RESERVED")
        self.assertEqual(second.reason_code, "COUPLED_CAPACITY_EXCEEDED")

    def test_retry_is_idempotent_and_does_not_double_reserve(self):
        first = self.store.reserve(key=KEY, execution_id="movement-A", amount=6, capacity_limit=10)
        retry = self.store.reserve(key=KEY, execution_id="movement-A", amount=6, capacity_limit=10)
        self.assertEqual(retry.reason_code, "CAPACITY_RESERVATION_IDEMPOTENT")
        self.assertEqual(retry.reservation_id, first.reservation_id)
        self.assertEqual(retry.reserved_after, 6)

    def test_execution_id_cannot_be_reused_with_changed_amount(self):
        self.store.reserve(key=KEY, execution_id="movement-A", amount=6, capacity_limit=10)
        conflict = self.store.reserve(key=KEY, execution_id="movement-A", amount=5, capacity_limit=10)
        self.assertEqual(conflict.reason_code, "EXECUTION_ID_CONFLICT")
        self.assertEqual(conflict.reserved_after, 6)

    def test_concurrent_sixes_cannot_both_reserve(self):
        barrier = threading.Barrier(3)
        results = []

        def reserve(execution_id):
            barrier.wait()
            results.append(self.store.reserve(
                key=KEY, execution_id=execution_id, amount=6, capacity_limit=10,
            ))

        threads = [threading.Thread(target=reserve, args=(name,)) for name in ("A", "B")]
        for thread in threads:
            thread.start()
        barrier.wait()
        for thread in threads:
            thread.join()
        self.assertEqual(sum(result.status == "RESERVED" for result in results), 1)
        self.assertEqual(sum(result.status == "REFUSE" for result in results), 1)


if __name__ == "__main__":
    unittest.main()
